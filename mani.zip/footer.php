<?php 
	$footer_logo = get_field('footer_logo' ,'option');
	$footer_copy = get_field('footer_copy' ,'option');
?>
<footer>
	<div class="row">
		<div class="large-12 column ">
			<div class="footer_logo">
				<img src="<?php echo $footer_logo['url']; ?>" title="" alt="">
			</div>
			<div class="footer_copy">
				<?php echo $footer_copy; ?>
			</div>
		</div>
	</div>
</footer>	

<?php wp_footer(); ?>

</body>
</html>
