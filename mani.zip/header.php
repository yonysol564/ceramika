<?php global $float; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php the_title(); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="clearfix"></div>
<header>
	<?php 
		$logo = get_field('main_logo' ,'option');
		$bg_img = get_field('bg_header' ,'option');
	?>
	<div class="bg_image" style="background-image: url(<?php echo $bg_img['url']; ?>)">
		<div class="row">
			<div class="logo_div">
				<a href="<?php echo home_url(); ?>" title="<?php the_title(); ?>"">
					<img src="<?php echo $logo['url']; ?>" title="" alt="logo">
				</a>
			</div>
		</div>

		
	</div>

	<nav>
		<div class="row">	
			<div class="title-bar" data-responsive-toggle="example-menu" data-hide-for="medium">
			  <button class="menu-icon" type="button" data-toggle></button>
			  <div class="title-bar-title"></div>
			</div>

			<div class="top-bar top_menu" id="example-menu">
			  <div class="top_bar_div">

			    <?php
		           	wp_nav_menu( array(
		                  'theme_location'    => 'top_menu',
		                  'menu_class'        => '',
		                  'container'         => '',
		                  'container_class'   => '',
		                  )
		            );
		        ?>
			  </div>
			</div>
		</div>
	</nav>

</header>

