<?php 
	$home_contact_form = get_field('home_contact_form', 'option');
	$home_contact_img = get_field('home_contact_img', 'option');
	$home_contact_title = get_field('home_contact_title', 'option');
	$home_contact_subtitle = get_field('home_contact_subtitle', 'option');
	$home_contact_phone = get_field('home_contact_phone', 'option');
?>

<section class="home_con_sec">
	<div class="row">
	
		<div class="large-7 column">

			<div class="hand_img">
				<img src="<?php echo $home_contact_img['url']; ?>" title="" alt="">
			</div>
			
			<div class="con_first_div">					
				<?php echo $home_contact_title; ?>
			</div>

			<div class="con_sec_div">
				<?php echo $home_contact_subtitle; ?>
			</div>

			<div class="con_third_div">
				או חייג:
				<div class="phone_link">
					<a href="tel:<?php echo $home_contact_phone; ?>" title=""><?php echo $home_contact_phone; ?></a>
					<img src="<?php echo THEME_DIR . '/images/phone_icon.png'; ?>" title="" alt="">
				</div>
			</div>

		</div>	
		<div class="large-5 column">
			<div class="form_div">
				<div class="inner_form">
					<?php echo do_shortcode($home_contact_form); ?>
				</div>
			</div>
		</div>		
	</div>
</section>