<?php 
	$real_estate_info = get_field('real_estate_info','option');
	$real_estate_img = get_field('real_estate_img','option');
	$real_estae_name = get_field('real_estae_name','option');
?>

<section class="home_about_sec">
	<div class="row">
		
		<div class="large-7 column">
			<div class="info_div">
				<?php echo $real_estate_info; ?>
			</div>
			<div class="infoname_div">
				<div class="row collapse">


					<div class="large-8 column">
						
					</div>
					<div class="large-4 column text-right">			
						<?php echo $real_estae_name; ?>
					</div>
				</div>
				
			</div>
		</div>

		<div class="large-5 column text-left">
			<img src="<?php echo $real_estate_img['url']; ?>" title="" alt="">
		</div>	
	</div>
</section>