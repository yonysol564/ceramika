<?php 
	$prop_agent_img = get_field('prop_agent_img');
	$term = '';
	if (is_page_template('archive-property.php')) {
		$terms = get_the_terms( $post->ID, 'location_cat' );
		if(!empty($terms)) {
			$term = reset($terms);
		}
	} elseif(is_tax()) {
		$term = get_queried_object();
	}
	
?>
<div class="row prop_row">
	<div class="large-12 column property_col">
		<div class="prop_agent">
			<div class="prop_agent_img">
				<img src="<?php echo $prop_agent_img['url']; ?>" title="<?php echo $prop_agent_name; ?>" alt="ssf">
			</div>
			<div class="prop_agent_namerole">
				<span class="prop_agent_name"><?php the_field('prop_agent_name'); ?></span> 
				<span>|</span> 
				<span class="prop_agent_role"><?php the_field('prop_agent_role'); ?></span>
			</div>
		</div>
		<div class="prop_dec">
			<div class="city_location">
				<?php echo $term->name; ?>
			</div>

			<div class="prop_description">
				<?php the_excerpt(); ?>
			</div>

			<div class="property_link">
				<a href="<?php echo get_permalink(); ?>" title="<?php echo get_the_title(); ?>">לפרטים נוספים על הנכס</a>
			</div>
		</div>

		<div class="slider_wrap">
			<ul class="prop_images">
				<?php if( have_rows('prop_img_gallery') ):
		            while ( have_rows('prop_img_gallery') ) : the_row();
		            $prop_img_gal = get_sub_field('prop_img_gal');
		         ?>
		         	<li>
		         		<div class="slide">
							<div class="prop_gallery_img">
								<img src="<?php echo $prop_img_gal['url']; ?>" title="" alt="">				
							</div>
						</div>
					</li>
		        <?php endwhile; endif; ?>
			</ul>
		</div>


	</div>
</div>