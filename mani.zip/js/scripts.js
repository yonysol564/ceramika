var slider;

jQuery(document).ready(function(){

  jQuery.scrollSpeed(180, 900);

  var window_width = jQuery( window ).width();
  

  
  // if (window_width < 767) {
  //   jQuery( ".single_arrows_row" ).insertBefore( ".single_mid_row" );
  // }

  if (window_width < 640) {
    jQuery( "nav" ).insertBefore( ".bg_image" );
  }


  jQuery( window ).resize(function() {
    //fix_single_arrows();
    fix_top_menu();
  });
 

  if(jQuery("#prop_map").length) {
      init_google_map("prop_map",locations[1],locations[2]);
  }

  //init_google_map_home();


  if(jQuery('.prop_images').length){
    jQuery('.prop_images').slick({
      infinite: true,
      speed: 500,
      autoplay: false,
      fade: true,
      rtl: true,
      autoplaySpeed: 2000,
      slidesToShow: 1,
      slidesToScroll: 1,
      focusOnSelect: false,
      arrows: false,
      responsive: [
        {
          breakpoint: 767,
          settings: {
            arrows:false,
            slidesToShow: 1
          }
        },
        {
          breakpoint: 480,
          settings: {
            dots:false,
            slidesToShow: 1
          }
        }
      ]
    });
  }

  // On before slide change
  jQuery('.single_prop_images').on('swipe', function(event, slick, currentSlide, nextSlide){
    var img_text = jQuery(this).find('.prop_gallery_img').data('text');
    jQuery('.img_text_append').html(img_text);  
   // console.log(img_text);
  });

 jQuery('.prev_slide').click(function(){
     jQuery(".single_prop_images").slick('slickPrev');
  });


jQuery('.next_slide').click(function(){
    jQuery(".single_prop_images").slick('slickNext');
});


//next_slide
  jQuery(".accordion-item").on("click", function (e) {
      if(jQuery(e.currentTarget).hasClass("slick-activated"))
          return;
      
      jQuery(e.currentTarget).addClass("slick-activated");

      var map_id = jQuery(this).find(".map_div").attr("id");
      create_accordion_map(map_id);
      var slick_number = jQuery(this).find(".slider-nav").data("counter");
      reinit_slick(slick_number);
  });

	jQuery(document).foundation();

});



jQuery(".single_prop_images").each(function(){
    data_counter = jQuery(this).data("counter");
    create_propety_slider(data_counter);
});

function reinit_slick(data_counter){
  jQuery(".slider-nav[data-counter="+data_counter+"]").slick("unslick");
  jQuery(".single_prop_images[data-counter="+data_counter+"]").slick("unslick");
  create_propety_slider(data_counter);
}

function create_propety_slider(data_counter){
  nav_element = jQuery(".slider-nav[data-counter="+data_counter+"]");
  main_element = jQuery(".single_prop_images[data-counter="+data_counter+"]");

  nav_element.slick({
    slidesToShow: 10,
    slidesToScroll: 1,
    asNavFor: '.single_prop_images_'+data_counter,
    dots: false,
    arrows: false,
    centerMode: true,
    focusOnSelect: true
  });
  update_slider_text_and_numbers(main_element);
  main_element.slick({
    asNavFor: '.slider-nav_'+data_counter,
    infinite: true,
    speed: 500,
    autoplay: false,
    fade: false,
    rtl: true,
    autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    focusOnSelect: false,
    arrows: false,
    responsive: [
      {
        breakpoint: 767,
        settings: {
          arrows:false,
          slidesToShow: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          dots:false,
          slidesToShow: 1
        }
      }
    ]
  }); 
}


function create_single_propety_slider(){
  nav_element = jQuery(".slider-nav");
  main_element = jQuery(".single_prop_images");

  nav_element.slick({
    slidesToShow: 10,
    slidesToScroll: 1,
    asNavFor: '.single_prop_images',
    dots: false,
    arrows: false,
    centerMode: true,
    focusOnSelect: true
  });

  update_single_slider_text_and_numbers(main_element);

  main_element.slick({
    asNavFor: '.slider-nav',
    infinite: true,
    speed: 500,
    autoplay: false,
    fade: false,
    rtl: true,
    autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    focusOnSelect: false,
    arrows: false,
    responsive: [
      {
        breakpoint: 767,
        settings: {
          arrows:false,
          slidesToShow: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          dots:false,
          slidesToShow: 1
        }
      }
    ]
  });
}

function update_slider_text_and_numbers(main_element){
  main_element.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
      if(typeof currentSlide == "undefined"){
        currentSlide = 0;
      }
      
      var img_text = main_element.parents("li").find(".slick-slide[data-slick-index=" + currentSlide + "] .prop_gallery_img").data('text');

      jQuery(this).parents("li").find('.img_text_append').html(img_text);

      //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
      var i = (currentSlide ? currentSlide : 0) + 1;

      jQuery(this).parents("li").find(".pagingInfo").text(slick.slideCount + ' - ' + i);
  });
}
 
function update_single_slider_text_and_numbers(main_element){
  main_element.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
      if(typeof currentSlide == "undefined"){
        currentSlide = 0;
      }
      
      var img_text = main_element.find(".slick-slide[data-slick-index=" + currentSlide + "] .prop_gallery_img").data('text');

      jQuery('.single_arrows_row').find('.img_text_append').html(img_text);

      //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
      var i = (currentSlide ? currentSlide : 0) + 1;

      jQuery('.single_arrows_row').find(".pagingInfo").text(slick.slideCount + ' - ' + i);
  });
}

function fix_single_arrows() {  
   var window_width = jQuery( window ).width();
    if (window_width > 767) {
      jQuery( ".single_mid_row" ).insertBefore( ".single_arrows_row" );
    }
    else{
       jQuery( ".single_arrows_row" ).insertBefore( ".single_mid_row" );
    }
}

function fix_top_menu() {  
   var window_width = jQuery( window ).width();
    if (window_width > 640) {
     //  console.log('bigeerrr 640');
      jQuery( ".bg_image" ).insertBefore( "nav" );
    }

    else{
      // console.log('640');
       jQuery( "nav" ).insertBefore( ".bg_image" );
    }
}

function init_google_map(id,lat,lon){
    map = new google.maps.Map(document.getElementById(id), {
      zoom: 16,
      scrollwheel: false,
      center: new google.maps.LatLng(lat,lon)
    });
    var infowindow = new google.maps.InfoWindow();
    var marker;

    marker = new google.maps.Marker({
      position: new google.maps.LatLng(lat, lon),
      map: map,
      animation: google.maps.Animation.DROP
    });
}

function create_accordion_map(map_id){
    var id = jQuery("#"+map_id).attr("id");
    var lat = jQuery("#"+map_id).data("lat");
    var lon = jQuery("#"+map_id).data("lon");
    init_google_map(id,lat,lon);
}

