<form role="search" method="get" action="<?php echo home_url(); ?>" >  
    <div class="input_div">
      <input class="form-control input_search" type="search" name="s" id="search" placeholder="<?php _e('Type here to search','insightec');?>">
    </div>
    <div class="input_button">
      <button class="search-submit" type="submit" role="button"><?php _e('Find','insightec');?></button>
    </div>
</form>