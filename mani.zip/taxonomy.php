<?php
$object = get_queried_object();
print_r($object);
get_header(); 
?>
<?php get_template_part('inc/info','main'); 
$terms = get_terms('location_cat');
?>

<section class="properties_sec">
	<div class="row properties_row">
		<div class="large-7 column">
			<div>
				באפשרותך לצפות בנכסים גם לפי איזור
			</div>
			<div class="locations_props">
				<ul>	
					<?php 
					foreach($terms as $term) {
					$term_link = get_term_link( $term );
					?>
						<li>
							<a href="<?php echo $term_link; ?>" title=""><?php echo $term->name; ?></a>
						</li>	
					<?php
					}
					?>
				</ul>
			</div>
		</div>
		<div class="large-5 column">
			<h2>
				הנכסים שלנו
			</h2>
		</div>			
	</div>

	<?php 
		foreach($terms as $term) {
		    wp_reset_query();
		    $args = array('post_type' => 'property',
		        'tax_query' => array(
		            array(
		                'taxonomy' => 'location_cat',
		                'field' => 'slug',
		                'terms' => $object->term_id,
		            ),
		        ),
		     );

		     $loop = new WP_Query($args);
		     if($loop->have_posts()) {
		        while($loop->have_posts()) : $loop->the_post();
			        $prop_agent_name = get_field('prop_agent_name');
			        $prop_agent_role = get_field('prop_agent_role');
			        $prop_agent_img = get_field('prop_agent_img');
		        	?>
					<div class="row prop_row">
						<div class="large-12 column property_col">
							<div class="prop_agent">
								<div class="prop_agent_img">
									<img src="<?php echo $prop_agent_img['url']; ?>" title="<?php echo $prop_agent_name; ?>" alt="ssf">
								</div>
								<div class="prop_agent_namerole">
									<span class="prop_agent_name"><?php echo $prop_agent_name; ?></span> 
									<span>|</span> 
									<span class="prop_agent_role"><?php echo $prop_agent_role; ?></span>
								</div>
							</div>
							<div class="prop_dec">
								<div class="city_location">
									<?php echo $term->name; ?>
								</div>

								<div class="prop_description">
									<?php the_excerpt(); ?>
								</div>

								<div class="property_link">
									<a href="<?php echo get_permalink(); ?>" title="<?php echo get_the_title(); ?>">לפרטים נוספים על הנכס</a>
								</div>
							</div>

							<div class="prop_images">
								<?php if( have_rows('prop_img_gallery') ):
						            while ( have_rows('prop_img_gallery') ) : the_row();
						            $prop_img_gal = get_sub_field('prop_img_gal');
						         ?>
									<div class="prop_gallery_img">
										<img src="<?php echo $prop_img_gal['url']; ?>" title="" alt="">				
									</div>
						        <?php endwhile; endif; ?>
							</div>
						</div>
					</div>
					<?php
		        endwhile;
		     }
		}
?>
</section>


<?php
get_sidebar();
get_footer();
?>