<?php
/* Template Name: About */ 
get_header(); 
?>

<?php 
	 $about_main_title = get_field('about_main_title');
	 $about_img = get_field('about_img');
	 $my_magic = get_field('my_magic');
	 $link_to_home = get_field('link_to_home');

?>


<?php
while ( have_posts() ) : the_post(); ?>

<section class="about_sec">
	<div class="row">
		


		<div class="large-5 column">
			<div>
				<h1><?php echo $about_main_title ?></h1>
			</div>

			<div class="border_about"></div>

			<div class="about_main_img">
				<img src="<?php echo $about_img['url']; ?>" title="" alt="">
			</div>			

		</div>	

		<div class="large-7 column">
			<div>
				<?php the_content();  ?>
			</div>
			
			<div class="my_magic">
				<?php echo $my_magic; ?>
			</div>

			<div class="back_home">
				<a href="<?php echo home_url(); ?>" title=""><?php echo $link_to_home; ?></a>
			</div>

		</div>

	</div>
</section>

<?php
endwhile; // End of the loop.
get_sidebar();
get_footer();
?>
