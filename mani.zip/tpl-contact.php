<?php
/* Template Name: Contact */ 
	get_header(); 
	$contact_form_page  = get_field('contact_form_page');
	$contact_email      = get_field('contact_email');
	$contact_img        = get_field('contact_img');
	$contact_magic_text = get_field('contact_magic_text');
	$contact_form_title = get_field('contact_form_page_title');
?>
<section class="contact_sec">
	<div class="row contact_row">


		<div class="large-6 column">
			<h2><?php echo $contact_form_title; ?></h2>
			<div class="form_div">
				<div class="inner_form">
					<?php echo do_shortcode($contact_form_page); ?>
				</div>
			</div>
		</div>
		
		<div class="large-6 column">
		<?php if( have_rows('contact_info_rep') ):
	            while ( have_rows('contact_info_rep') ) : the_row();
	            $contact_icon = get_sub_field('contact_icon');
	            $contact_desc = get_sub_field('contact_info_desc');
	            $contact_info_title = get_sub_field('contact_info_title');
	         ?>
				<div class="con_row">
					<div class="icon_div">
						<img src="<?php echo $contact_icon['url']; ?>" title="" alt="">
					</div>
					<div class="text_div">
						<h3><?php echo $contact_info_title; ?></h3>
						<p>
							<?php echo $contact_desc; ?>
						</p>
					</div>
					<div class="clearfix"></div>
				</div>
	        <?php endwhile; endif; ?>

			<div class="con_row con_detailes">
				<div class="icon_div">
					&nbsp;
				</div>
				<div class="text_div">
					<p>
					דוא"ל: <a href="mailto:<?php echo $contact_email; ?>" title="email"><?php echo $contact_email; ?></a>	
					</p>
				</div>
				<div class="clearfix"></div>
			</div>

			<div class="con_row con_detailes">
				<div class="icon_div woman_div">
					<img src="<?php echo $contact_img['url']; ?>" title="" alt="">
				</div>
				<div class="text_div woman_text">
					<p>
						<?php echo $contact_magic_text; ?>
					</p>
				</div>
				<div class="clearfix"></div>
			</div>	
		</div>			
	</div>
</section>

<?php
get_sidebar();
get_footer();
