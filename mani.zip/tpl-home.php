<?php
/* Template Name: Homepage */ 
get_header(); 
$terms = get_terms('location_cat');
?>


<?php get_template_part('inc/info','main'); ?>
	
<?php 
	$args = array(
    'post_type' => array( 'property'),
    'posts_per_page' => -1
);
$property = new WP_Query( $args );
?>

<section class="property_sec">

	<div class="row">
		<ul class="accordion" data-accordion>
			<?php
			$cnt = 1;
			while ( $property->have_posts() ) : $property->the_post(); ?>
			  	<li class="accordion-item <?php if( $cnt == 1 ) { echo 'is-active'; } ?>" data-accordion-item>
				    <a href="#" class="accordion-title"><?php the_title(); ?></a>
				    <div class="accordion-content" data-tab-content>
				      	<div class="row single_top_row">
							<div class="large-9 column sing_col_9">
								<div class="single_loc_name">
									<h2><?php echo get_the_term_list( $post->ID, 'location_cat', '', ', ' ); ?>,&nbsp;<span class="zone"><?php the_title(); ?></span></h2>
								</div>
								
								<div class="single_loc_attr">
									<?php $prop_type  =  get_field('prop_type'); ?>
									<?php $prop_size  =  get_field('prop_size'); ?>
									<?php $prop_price =  get_field('prop_price'); ?>
									<span><?php echo $prop_type; ?></span> |
									<span><?php echo $prop_size; ?></span>
								</div>

								<div class="slider-nav" data-counter="<?php echo $cnt;?>">
									<?php if( have_rows('prop_img_gallery') ):
							            while ( have_rows('prop_img_gallery') ) : the_row();
							            $prop_img_gal = get_sub_field('prop_img_gal');
							            $prop_img_gal_text = get_sub_field('prop_img_gal_text');
							         ?>
											<div class="" data-text="<?php echo $prop_img_gal_text; ?>">
												<img src="<?php echo $prop_img_gal['url']; ?>" title="" alt="">				
											</div>
							        <?php endwhile; endif; ?>
								</div>
							</div>
							<div class="large-3 column sing_col_3">
								<?php $location = get_field('prop_map'); ?>
								<div class="map_div" id="prop_map_<?php echo $cnt; ?>" data-lat="<?php echo $location['lat']; ?>" data-lon="<?php echo $location['lng']; ?>">
								</div>
							</div>
						</div>

						<div class="row single_mid_row">
							<div class="large-9 column sing_col_9 gallery_col">		
								<div class="single_slider_wrap">
									<div class="single_prop_images single_prop_images_<?php echo $cnt;?>" data-counter="<?php echo $cnt;?>">
										<?php if( have_rows('prop_img_gallery') ):
								            while ( have_rows('prop_img_gallery') ) : the_row();
								            $prop_img_gal = get_sub_field('prop_img_gal');
								            $prop_img_gal_text = get_sub_field('prop_img_gal_text');
								         ?>
							         		<div class="">
												<div class="prop_gallery_img" data-text="<?php echo $prop_img_gal_text; ?>">
													<img src="<?php echo $prop_img_gal['url']; ?>" title="" alt="">				
												</div>
											</div>
								        <?php endwhile; endif; ?>
									</div>
								</div>
							</div>
							<div class="large-3 column col_attrs sing_col_3">
								<div class="single_attrs">
									<?php if( have_rows('prop_features') ):
							            while ( have_rows('prop_features') ) : the_row();
							            $prop_feature = get_sub_field('prop_feature');
							            $prop_feature_check = get_sub_field('prop_feature_check'); 
							         ?>
						         		<div class="wrap_attr">
											<span class="checks_img">
												<?php if ($prop_feature_check) { ?>

												<img src="<?php echo THEME_DIR . '/images/viprop.jpg'; ?>" title="" alt="">

												<?php } else { ?>

												<img src="<?php echo THEME_DIR . '/images/vi_not.jpg'; ?>" title="" alt="">	

												<?php } ?>
											</span>
											<span class="check_title">	
												<?php echo $prop_feature; ?>
											</span>
										</div>
							        <?php endwhile; endif; ?>
								</div>
								<div class="single_price">	
									<div class="inner_p">
										<span><?php echo $prop_price; ?></span>
										<span>&#8362;&nbsp;</span>
										
									</div>
								</div>
							</div>
						</div>

						<div class="row single_arrows_row">

							<div class="large-9 column sing_col_9">
								<div class="row img_title_div_pad">

									<div class="large-6 medium-6 small-12 column">
										<div class="img_title_div">	
											<span class="img_text_append"></span>
										</div>
									</div>


									<div class="large-6 medium-6 small-12 column arrows_col">
										<button class="next_slide"> < </button>
										<div class="pagingInfo"></div>
										<button class="prev_slide"> > </button>				
									</div>

								</div>
								<div class="row">
									<div class="large-12 column">
										<div class="sing_border_div"></div>
									</div>
								</div>
							</div>

							<div class="large-3 column sing_col_3 col_dis">
								&nbsp;
							</div>
						</div>

						<div class="row single_agent_row">
							<?php 
								$prop_agent_img   = get_field('prop_agent_img'); 
								$prop_agent_email = get_field('prop_agent_email'); 
								$prop_agent_phone = get_field('prop_agent_phone'); 
								$form_request =     get_field('property_form_request'); 

								$property_form_requests  = get_field('property_form_requests', 'option'); 
								$prop_general_visit 	 = get_field('prop_general_visit', 'option'); 
								$prop_general_phone		 = get_field('prop_general_visit_phone', 'option'); 
								$prop_general_infoform   = get_field('prop_general_infoform', 'option'); 
								$prop_general_moreinfo  = get_field('prop_general_moreinfo', 'option'); 	
								$prop_general_linkprop  = get_field('prop_general_linkprop', 'option'); 	
							?>


							<div class="large-9 column sing_col_9">
								<div class="">
									<div class="single_excerpt">
										<?php the_excerpt(); ?>
									</div>
									<div class="agent_border"></div>

									<div class="single_visit">
										<div class="inner_visit"><?php echo $prop_general_visit; ?> 
											
											<a href="tel:<?php echo $prop_general_phone; ?>" title=""><?php echo $prop_general_phone; ?></a>
											<img src="<?php echo THEME_DIR . '/images/phone_icon.png'; ?>" title="" alt=""> 
											
										</div>
										<div class="inner_visit"> <?php echo $prop_general_infoform; ?> </div>
									</div>
									<?php echo do_shortcode($property_form_requests); ?>
								</div>
							</div>

							<div class="large-3 column sing_col_3">
								<div class="single_agent_img" style="background-image: url(<?php echo $prop_agent_img['url']; ?>); ">	

								</div>
								<div class="prop_agent_namerole">
									<span class="prop_agent_name"><?php the_field('prop_agent_name'); ?></span> 
									<span>|</span> 
									<span class="prop_agent_role"><?php the_field('prop_agent_role'); ?></span>
								</div>
								<div class="prop_agent_phone">
									<span>נייד:</span><span><?php echo $prop_agent_phone; ?></span> 
								</div>
								<div class="prop_agent_email">
									<span>דוא"ל:</span><span><?php echo $prop_agent_email; ?></span> 
								</div>
							</div>
						</div>

						<div class="row border_row">	
							<div class="large-12 column">	
								<div class="sing_border_div"></div>
							</div>
						</div>
					</div>
				</li>
			<?php
			$cnt++;
			endwhile; // End of the loop. ?>
		</ul>
	</div>
</section>


<?php
get_template_part('inc/contact','sec'); ?>


<?php
get_sidebar();
get_footer();
